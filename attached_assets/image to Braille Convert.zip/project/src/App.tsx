import React, { useRef, useState } from 'react';
import { createWorker } from 'tesseract.js';
import { Upload, RefreshCw, Copy, Volume2, Download } from 'lucide-react';
import { textToBraille } from './brailleMap';

function App() {
  const [image, setImage] = useState<string | null>(null);
  const [text, setText] = useState<string>('');
  const [braille, setBraille] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const processImage = async (imageSource: string) => {
    setIsProcessing(true);
    try {
      const worker = await createWorker();
      await worker.loadLanguage('eng');
      await worker.initialize('eng');
      const { data: { text } } = await worker.recognize(imageSource);
      setText(text);
      setBraille(textToBraille(text));
      await worker.terminate();
    } catch (error) {
      console.error('Error processing image:', error);
      setText('Error processing image. Please try again.');
    }
    setIsProcessing(false);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const imageDataUrl = reader.result as string;
        setImage(imageDataUrl);
        processImage(imageDataUrl);
      };
      reader.readAsDataURL(file);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const speakText = () => {
    if ('speechSynthesis' in window) {
      if (isSpeaking) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
        return;
      }

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.onend = () => setIsSpeaking(false);
      setIsSpeaking(true);
      window.speechSynthesis.speak(utterance);
    }
  };

  const renderBrailleCards = () => {
    return text.split(' ').map((word, index) => {
      const brailleWord = textToBraille(word.toUpperCase());
      return (
        <div key={index} className="bg-white rounded-lg shadow-sm p-4 flex flex-col items-center">
          <div className="text-3xl mb-2">{brailleWord}</div>
          <div className="text-sm text-gray-600">{word}</div>
        </div>
      );
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h1 className="text-3xl font-bold text-center text-indigo-900 mb-8">
            Image to Braille Converter
          </h1>

          <div className="space-y-6">
            <div className="space-y-4">
              <div className="flex justify-center">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-2 bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
                >
                  <Upload size={20} />
                  Upload Image
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>

              {image && (
                <div className="relative">
                  <img
                    src={image}
                    alt="Uploaded"
                    className="w-full rounded-lg"
                  />
                  <button
                    onClick={() => {
                      setImage(null);
                      setText('');
                      setBraille('');
                    }}
                    className="absolute top-2 right-2 bg-white p-2 rounded-full shadow-md hover:bg-gray-100"
                  >
                    <RefreshCw size={20} />
                  </button>
                </div>
              )}
            </div>

            {isProcessing && (
              <div className="text-center text-indigo-600">
                Processing image...
              </div>
            )}

            {text && (
              <div className="space-y-6">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <h2 className="text-lg font-semibold text-gray-700">
                      Detected Text
                    </h2>
                    <div className="flex gap-2">
                      <button
                        onClick={speakText}
                        className={`text-indigo-600 hover:text-indigo-800 ${isSpeaking ? 'text-indigo-800' : ''}`}
                        title={isSpeaking ? 'Stop Speaking' : 'Read Text'}
                      >
                        <Volume2 size={20} />
                      </button>
                      <button
                        onClick={() => copyToClipboard(text)}
                        className="text-indigo-600 hover:text-indigo-800"
                        title="Copy Text"
                      >
                        <Copy size={20} />
                      </button>
                    </div>
                  </div>
                  <p className="text-gray-600">{text}</p>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg">
                  <div className="flex justify-between items-center mb-4">
                    <h2 className="text-lg font-semibold text-gray-700">
                      Braille Translation
                    </h2>
                    <div className="flex gap-2">
                      <button
                        onClick={() => copyToClipboard(braille)}
                        className="text-indigo-600 hover:text-indigo-800"
                        title="Copy Braille"
                      >
                        <Copy size={20} />
                      </button>
                      <button
                        onClick={() => {}} // Add download functionality if needed
                        className="text-indigo-600 hover:text-indigo-800"
                        title="Download Braille"
                      >
                        <Download size={20} />
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                    {renderBrailleCards()}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;