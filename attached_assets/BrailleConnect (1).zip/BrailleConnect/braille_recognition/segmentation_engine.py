import cv2
import numpy as np
import logging
from math import sqrt
from collections import Counter
from .braille_character import BrailleCharacter

logger = logging.getLogger(__name__)

class SegmentationEngine(object): 
    def __init__(self, image=None):
        self.image = image
        self.initialized = False
        self.dots = []
        self.diameter = 0.0
        self.radius = 0.0
        self.next_epoch = 0
        self.characters = []
        return

    def __iter__(self):
        return self

    def __next__(self):
        return self.next()

    def next(self):
        if not self.initialized:
            self.initialized = True
            contours = self.__process_contours()
            if len(contours) == 0:
                # Since we have no dots.
                self.__clear()
                raise StopIteration()
            enclosingCircles = self.__get_min_enclosing_circles(contours)
            if len(enclosingCircles) == 0:
                self.__clear()
                raise StopIteration()

            diameter, dots, radius = self.__get_valid_dots(enclosingCircles)
            if len(dots) == 0:
                self.__clear()
                raise StopIteration()
            self.diameter = diameter
            self.dots = dots
            self.radius = radius
            self.next_epoch = 0
            self.characters = []

        if len(self.characters) > 0:
            r = self.characters[0]
            del self.characters[0]
            return r

        cor = self.__get_row_cor(self.dots, epoch=self.next_epoch)  # do not respect breakpoints
        if cor is None:
            self.__clear()
            raise StopIteration()

        top = int(cor[1] - int(self.radius*1.5))  # y coordinate
        self.next_epoch = int(cor[1] + self.radius)

        cor = self.__get_row_cor(self.dots, self.next_epoch, self.diameter, True)
        if cor is None:
            # Assume next epoch
            self.next_epoch = int(self.next_epoch + (2*self.diameter))
        else:
            self.next_epoch = int(cor[1] + self.radius)

        cor = self.__get_row_cor(self.dots, self.next_epoch, self.diameter, True)
        if cor is None:
            self.next_epoch = int(self.next_epoch + (2*self.diameter))
        else:
            self.next_epoch = int(cor[1] + self.radius)
        
        bottom = self.next_epoch
        self.next_epoch += int(2*self.diameter)

        DOI = self.__get_dots_from_region(self.dots, top, bottom)
        xnextEpoch = 0
        while True:
            xcor = self.__get_col_cor(DOI, xnextEpoch)
            if xcor is None:
                break

            left = int(xcor[0] - self.radius)  # x coordinate
            xnextEpoch = int(xcor[0] + self.radius)
            xcor = self.__get_col_cor(DOI, xnextEpoch, self.diameter, True)
            if xcor is None:
                # Assumed
                xnextEpoch += int(self.diameter*1.5)
            else:
                xnextEpoch = int(xcor[0]) + int(self.radius)
            right = xnextEpoch
            box = (left, right, top, bottom)
            dts = self.__get_dots_from_box(DOI, box)
            char = BrailleCharacter(dts, self.diameter, self.radius, self.image)
            char.left = left
            char.right = right
            char.top = top
            char.bottom = bottom
            self.characters.append(char)

        if len(self.characters) < 1:
            self.__clear()
            raise StopIteration()

        r = self.characters[0]
        del self.characters[0]
        return r

    def __clear(self):
        self.image = None
        self.initialized = False
        self.dots = []
        self.diameter = 0.0
        self.radius = 0.0
        self.next_epoch = 0
        self.characters = []

    def update(self, image):
        self.__clear()
        self.image = image
        return True

    def __get_row_cor(self, dots, epoch=0, diameter=0, respectBreakpoint=False):
        if len(dots) == 0:
            return None
        minDot = None

        # Loop to get closest coordinate to the y-epoch if any
        for dot in dots:
            coord = dot[0]
            if coord[1] > epoch:
                if minDot is None:
                    minDot = dot
                else:
                    minc = minDot[0]
                    if minc[1] > coord[1]:
                        minDot = dot

        if minDot is None:
            # All dots are below the y-epoch. Not good.
            return None

        min_coord = minDot[0]
        if respectBreakpoint and (diameter > 0):
            if min_coord[1] > epoch + diameter:
                # Since there's a "breakpoint" with a gap of (diameter/2)
                # we will just return None
                return None

        return min_coord

    def __get_col_cor(self, dots, epoch=0, diameter=0, respectBreakpoint=False):
        if len(dots) == 0:
            return None
        minDot = None

        # Loop to get closest coordinate to the x-epoch if any
        for dot in dots:
            coord = dot[0]
            if coord[0] > epoch:
                if minDot is None:
                    minDot = dot
                else:
                    minc = minDot[0]
                    if minc[0] > coord[0]:
                        minDot = dot

        if minDot is None:
            # All dots are to the left of the x-epoch. Not good.
            return None

        min_coord = minDot[0]
        if respectBreakpoint and (diameter > 0):
            if min_coord[0] > epoch + diameter:
                # Since there's a "breakpoint" with a gap of (diameter/2)
                # we will just return None
                return None

        return min_coord

    def __get_dots_from_region(self, dots, top, bottom):
        result = []
        for dot in dots:
            coord = dot[0]
            if coord[1] >= top and coord[1] <= bottom:
                result.append(dot)
        return result

    def __get_dots_from_box(self, dots, box):
        result = []
        if len(dots) < 1:
            return result
        left, right, top, bottom = box
        for dot in dots:
            coord = dot[0]
            x, y = coord
            if x >= left and x <= right and y >= top and y <= bottom:
                result.append(dot)
        return result

    def __process_contours(self):
        if self.image is None:
            return []
        
        image = self.image.get_edged_binary_image()
        contours, _ = cv2.findContours(image, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        # Logger debug: Number of contours found
        logger.debug(f"Found {len(contours)} contours")
        return contours

    def __get_min_enclosing_circles(self, contours):
        circles = []
        for contour in contours:
            if len(contour) >= 5:
                # Find the min enclosing circle that may represent a Braille dot
                (x, y), radius = cv2.minEnclosingCircle(contour)
                center = (int(x), int(y))
                radius = int(radius)
                
                # Use contour area as a filter
                area = cv2.contourArea(contour)
                
                # Only accept potential dots within a reasonable size range
                if radius > 2 and radius < 20 and area > 20:
                    circles.append((center, radius))
            
        logger.debug(f"Found {len(circles)} potential Braille dots")
        return circles

    def __get_valid_dots(self, enclosingCircles):
        if len(enclosingCircles) < 1:
            return (0.0, [], 0.0)
        
        # Extract radii for filtering
        radii = [c[1] for c in enclosingCircles]
        
        # Find the most common radius as the baseline
        baserad = Counter(radii).most_common(1)[0][0]
        dots = []
        
        # Calculate an acceptable range for dot radii (within 30% of baseline)
        min_radius = baserad * 0.7
        max_radius = baserad * 1.3
        
        # Filter dots by radius
        for circle in enclosingCircles:
            center, radius = circle
            if min_radius <= radius <= max_radius:
                dots.append(circle)
                
        # Calculate diameter (2 * median radius)
        diameter = baserad * 2
        
        logger.debug(f"Filtered to {len(dots)} valid Braille dots with avg diameter {diameter}")
        return (diameter, dots, baserad)