import logging
import cv2
from .braille_image import BrailleImage
from .segmentation_engine import SegmentationEngine
from .braille_classifier import BrailleClassifier, get_combination

logger = logging.getLogger(__name__)

class BrailleRecognizer:
    def __init__(self):
        self.classifier = BrailleClassifier()
    
    def process_image(self, image_path):
        """
        Process a Braille image and extract text
        
        Args:
            image_path (str): Path to the Braille image
            
        Returns:
            tuple: (text, marked_image_path) where text is the extracted text and
                  marked_image_path is the path to the image with Braille dots marked
        """
        try:
            logger.debug(f"Processing Braille image: {image_path}")
            
            # Initialize the Braille image
            braille_img = BrailleImage(image_path)
            
            # Initialize the segmentation engine
            segmentation = SegmentationEngine(braille_img)
            
            # Extract text from the image
            result = ""
            for character in segmentation:
                if not character.is_valid():
                    continue
                    
                box = character.get_bounding_box()
                character.mark()  # Mark the character boundaries in the image
                
                # Get Braille dot pattern combination
                dots = character.get_dot_coordinates().copy()
                diameter = character.get_dot_diameter()
                _, _, _, pattern = get_combination(box, dots, diameter)
                
                # Classify the pattern
                symbol = self.classifier.classify(pattern)
                if symbol is not None:
                    result += symbol
            
            # If no text was recognized, return a helpful message
            if not result:
                result = "No Braille text detected in the image. Please upload a clearer image with well-defined Braille dots."
            
            logger.debug(f"Recognized text: {result}")
            
            # Return the recognized text and the processed image
            return result, braille_img.get_final_image()
            
        except Exception as e:
            logger.error(f"Error processing Braille image: {str(e)}")
            raise Exception(f"Failed to process Braille image: {str(e)}")
    
    def save_marked_image(self, image, output_path):
        """
        Save the marked image to disk
        
        Args:
            image: OpenCV image
            output_path (str): Path to save the marked image
            
        Returns:
            str: Path to the saved image
        """
        try:
            cv2.imwrite(output_path, image)
            return output_path
        except Exception as e:
            logger.error(f"Error saving marked image: {str(e)}")
            return None