/**
 * Main JavaScript file for Braillify
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                window.scrollTo({
                    top: target.offsetTop - 70, // Adjust for navbar height
                    behavior: 'smooth'
                });
            }
        });
    });

    // File input label update
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fileInputs.forEach(input => {
        input.addEventListener('change', function(e) {
            // Get the file name
            let fileName = '';
            if (this.files && this.files.length > 0) {
                fileName = this.files[0].name;
            }
            
            // Find the label or create a placeholder
            let fileLabel = this.nextElementSibling;
            if (!fileLabel || !fileLabel.classList.contains('form-file-label')) {
                fileLabel = document.createElement('div');
                fileLabel.classList.add('form-text', 'mt-2');
                this.parentNode.insertBefore(fileLabel, this.nextSibling);
            }
            
            // Update the label with file name or default text
            fileLabel.textContent = fileName || 'No file chosen';
        });
    });

    // Handle button micro-interactions
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(btn => {
        btn.addEventListener('mousedown', function() {
            this.style.transform = 'scale(0.98)';
        });
        
        btn.addEventListener('mouseup', function() {
            this.style.transform = 'scale(1)';
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });
    
    // Back to top button
    const createBackToTopButton = () => {
        const btn = document.createElement('button');
        btn.innerHTML = '<i class="fas fa-arrow-up"></i>';
        btn.setAttribute('id', 'back-to-top');
        btn.style.position = 'fixed';
        btn.style.bottom = '20px';
        btn.style.right = '20px';
        btn.style.height = '50px';
        btn.style.width = '50px';
        btn.style.borderRadius = '50%';
        btn.style.backgroundColor = '#4e73df';
        btn.style.color = 'white';
        btn.style.border = 'none';
        btn.style.display = 'none';
        btn.style.opacity = '0.7';
        btn.style.cursor = 'pointer';
        btn.style.zIndex = '1000';
        btn.style.boxShadow = '0 4px 8px rgba(0,0,0,0.1)';
        
        btn.addEventListener('mouseover', function() {
            this.style.opacity = '1';
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.opacity = '0.7';
        });
        
        btn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
        
        document.body.appendChild(btn);
        
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                btn.style.display = 'block';
            } else {
                btn.style.display = 'none';
            }
        });
    };
    
    createBackToTopButton();
    
    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
    
    // Animate on scroll
    const animateOnScroll = () => {
        const elements = document.querySelectorAll('.animate-on-scroll');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animated');
                }
            });
        }, { threshold: 0.1 });
        
        elements.forEach(element => {
            observer.observe(element);
        });
    };
    
    // Check if IntersectionObserver is supported
    if ('IntersectionObserver' in window) {
        animateOnScroll();
    } else {
        // Fallback for browsers that don't support IntersectionObserver
        document.querySelectorAll('.animate-on-scroll').forEach(element => {
            element.classList.add('animated');
        });
    }
    
    // Add functionality for the tab navigation
    const tabLinks = document.querySelectorAll('.nav-tabs .nav-link');
    if (tabLinks.length > 0) {
        tabLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Hide all tab panes
                const tabPanes = document.querySelectorAll('.tab-pane');
                tabPanes.forEach(pane => {
                    pane.classList.remove('show', 'active');
                });
                
                // Deactivate all tabs
                tabLinks.forEach(tab => {
                    tab.classList.remove('active');
                    tab.setAttribute('aria-selected', 'false');
                });
                
                // Activate clicked tab
                this.classList.add('active');
                this.setAttribute('aria-selected', 'true');
                
                // Show target tab pane
                const target = document.querySelector(this.getAttribute('data-bs-target'));
                if (target) {
                    target.classList.add('show', 'active');
                }
            });
        });
    }
});
