"""
Utility functions for Braille conversion
"""
import logging

logger = logging.getLogger(__name__)

# Braille character mapping (English)
# Each Braille character is represented by a 2x3 matrix of dots
# We'll use '⠿' to represent a raised dot and '⠄' to represent no dot
BRAILLE_ALPHABET = {
    'a': '⠁', 'b': '⠃', 'c': '⠉', 'd': '⠙', 'e': '⠑',
    'f': '⠋', 'g': '⠛', 'h': '⠓', 'i': '⠊', 'j': '⠚',
    'k': '⠅', 'l': '⠇', 'm': '⠍', 'n': '⠝', 'o': '⠕',
    'p': '⠏', 'q': '⠟', 'r': '⠗', 's': '⠎', 't': '⠞',
    'u': '⠥', 'v': '⠧', 'w': '⠺', 'x': '⠭', 'y': '⠽',
    'z': '⠵', ' ': '⠀', '0': '⠼⠚', '1': '⠼⠁', '2': '⠼⠃',
    '3': '⠼⠉', '4': '⠼⠙', '5': '⠼⠑', '6': '⠼⠋', '7': '⠼⠛',
    '8': '⠼⠓', '9': '⠼⠊', '.': '⠲', ',': '⠂', '?': '⠦',
    '!': '⠖', "'": '⠄', '-': '⠤', ':': '⠒', ';': '⠆'
}

# Reverse mapping for Braille to text conversion
BRAILLE_TO_TEXT = {v: k for k, v in BRAILLE_ALPHABET.items()}

def text_to_braille(text):
    """
    Convert text to Braille representation
    
    Args:
        text (str): The input text to convert
    
    Returns:
        str: The Braille representation of the input text
    """
    logger.debug(f"Converting text to Braille: {text}")
    
    if not text:
        return ""
    
    # Convert to lowercase for simplicity
    text = text.lower()
    
    # Convert each character to its Braille equivalent
    braille_result = ""
    for char in text:
        if char in BRAILLE_ALPHABET:
            braille_result += BRAILLE_ALPHABET[char]
        else:
            # If character is not in our mapping, keep it as is
            braille_result += char
    
    logger.debug(f"Braille result: {braille_result}")
    return braille_result

def braille_to_text(image_path):
    """
    Convert a Braille image to text
    
    Args:
        image_path (str): Path to the image containing Braille dots
    
    Returns:
        str: The text representation of the Braille image
    """
    logger.debug(f"Converting Braille image to text: {image_path}")
    
    try:
        # Import the BrailleRecognizer from our new module
        from braille_recognition.braille_recognizer import BrailleRecognizer
        
        # Create a BrailleRecognizer instance
        recognizer = BrailleRecognizer()
        
        # Process the image and extract text
        text, _ = recognizer.process_image(image_path)
        return text
    except ImportError:
        logger.error("BrailleRecognizer module not found. Falling back to placeholder.")
        return "Braille recognition functionality is not available. Please check system configuration."
    except Exception as e:
        logger.error(f"Error in Braille recognition: {str(e)}")
        return f"Failed to process Braille image: {str(e)}"

def get_braille_dot_pattern(char):
    """
    Get the 2x3 dot pattern for a Braille character
    
    Args:
        char (str): Braille character
    
    Returns:
        list: 2D array representing the dot pattern (1 for raised dot, 0 for no dot)
    """
    # This would normally decode the Unicode Braille character into its dot pattern
    # For simplicity, we're returning a placeholder
    return [[1, 0], [0, 1], [1, 1]]  # Example pattern
