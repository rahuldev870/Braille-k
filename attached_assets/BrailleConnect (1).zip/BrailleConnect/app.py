import os
import logging
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from werkzeug.utils import secure_filename
import tempfile
import braille_utils
import image_utils
import audio_utils

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "braillify_default_secret_key")

# Configure upload settings
UPLOAD_FOLDER = tempfile.gettempdir()
ALLOWED_EXTENSIONS_IMAGE = {'png', 'jpg', 'jpeg', 'gif'}
ALLOWED_EXTENSIONS_AUDIO = {'wav', 'mp3', 'ogg'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

def allowed_file(filename, allowed_extensions):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/braille-to-speech', methods=['GET', 'POST'])
def braille_to_speech():
    result = None
    text_output = None
    error = None
    speak_results = False
    
    if request.method == 'POST':
        # Check if automatic speech synthesis is requested
        speak_results = 'speakResults' in request.form
        
        if 'braille_image' not in request.files:
            error = "No file part"
        else:
            file = request.files['braille_image']
            if file.filename == '':
                error = "No selected file"
            elif file and allowed_file(file.filename, ALLOWED_EXTENSIONS_IMAGE):
                filename = secure_filename(file.filename)
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                
                try:
                    # Process the Braille image using the advanced recognition
                    text_output = braille_utils.braille_to_text(filepath)
                    result = {
                        'success': True,
                        'text': text_output,
                        'speak': speak_results
                    }
                    logger.debug(f"Successfully extracted text from Braille image: {text_output}")
                except Exception as e:
                    logger.error(f"Error processing file: {str(e)}")
                    error = f"Error processing file: {str(e)}"
                    result = {
                        'success': False,
                        'error': error
                    }
                
                # Clean up the temporary file (only if not in debug mode for easier troubleshooting)
                if not app.debug:
                    os.remove(filepath)
            else:
                error = "File type not allowed. Please upload an image file (png, jpg, jpeg, gif)."
    
    return render_template('braille_to_speech.html', result=result, text_output=text_output, error=error)

@app.route('/image-to-braille', methods=['GET', 'POST'])
def image_to_braille():
    result = None
    braille_output = None
    detected_objects = None
    extracted_text = None
    error = None
    
    if request.method == 'POST':
        if 'image' not in request.files:
            error = "No file part"
        else:
            file = request.files['image']
            if file.filename == '':
                error = "No selected file"
            elif file and allowed_file(file.filename, ALLOWED_EXTENSIONS_IMAGE):
                filename = secure_filename(file.filename)
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                
                try:
                    # Extract text from the image using OCR
                    extracted_text = image_utils.extract_text_from_image(filepath)
                    
                    # Convert extracted text to Braille
                    braille_text = braille_utils.text_to_braille(extracted_text)
                    
                    # For backward compatibility with the template
                    detected_objects = {"extracted_text": 1.0}
                    braille_output = {"extracted_text": braille_text}
                    
                    result = {
                        'success': True,
                        'extracted_text': extracted_text,
                        'braille_text': braille_text,
                        'detected_objects': detected_objects,
                        'braille_output': braille_output
                    }
                except Exception as e:
                    logger.error(f"Error processing file: {str(e)}")
                    error = f"Error processing file: {str(e)}"
                    result = {
                        'success': False,
                        'error': error
                    }
                
                # Clean up the temporary file (only if not in debug mode for easier troubleshooting)
                if not app.debug:
                    os.remove(filepath)
            else:
                error = "File type not allowed. Please upload an image file (png, jpg, jpeg, gif)."
    
    return render_template('image_to_braille.html', result=result, 
                           braille_output=braille_output, 
                           detected_objects=detected_objects,
                           extracted_text=extracted_text,
                           error=error)

@app.route('/text-to-braille', methods=['GET', 'POST'])
def text_to_braille():
    result = None
    braille_output = None
    input_text = None
    error = None
    
    if request.method == 'POST':
        if 'text_input' in request.form and request.form['text_input'].strip():
            try:
                input_text = request.form['text_input']
                braille_output = braille_utils.text_to_braille(input_text)
                result = {
                    'success': True,
                    'input_text': input_text,
                    'braille_output': braille_output
                }
            except Exception as e:
                logger.error(f"Error converting text to Braille: {str(e)}")
                error = f"Error converting text to Braille: {str(e)}"
                result = {
                    'success': False,
                    'error': error
                }
        elif 'audio_file' in request.files:
            file = request.files['audio_file']
            if file.filename == '':
                error = "No selected file"
            elif file and allowed_file(file.filename, ALLOWED_EXTENSIONS_AUDIO):
                filename = secure_filename(file.filename)
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                
                try:
                    # Process the audio file to get text
                    input_text = audio_utils.audio_to_text(filepath)
                    
                    # Convert text to Braille
                    braille_output = braille_utils.text_to_braille(input_text)
                    
                    result = {
                        'success': True,
                        'input_text': input_text,
                        'braille_output': braille_output
                    }
                except Exception as e:
                    logger.error(f"Error processing audio file: {str(e)}")
                    error = f"Error processing audio file: {str(e)}"
                    result = {
                        'success': False,
                        'error': error
                    }
                
                # Clean up the temporary file
                os.remove(filepath)
            else:
                error = "File type not allowed. Please upload an audio file (wav, mp3, ogg)."
        else:
            error = "No text or audio input provided."
    
    return render_template('text_to_braille.html', result=result, 
                           braille_output=braille_output, 
                           input_text=input_text, 
                           error=error)

@app.route('/api/speech', methods=['POST'])
def speech_api():
    """API endpoint for text-to-speech conversion"""
    try:
        data = request.get_json()
        text = data.get('text', '')
        if not text:
            return jsonify({'success': False, 'error': 'No text provided'})
        
        # Note: In a real implementation, you would generate and return audio data
        # Here we just acknowledge receipt of the text to be spoken
        return jsonify({'success': True, 'message': f'Text "{text}" would be spoken'})
    except Exception as e:
        logger.error(f"Error in speech API: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.errorhandler(413)
def too_large(e):
    return "File is too large", 413

@app.errorhandler(404)
def page_not_found(e):
    return render_template('index.html'), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
