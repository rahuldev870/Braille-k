
import React from 'react';
import BrailleConverter from '@/components/BrailleConverter';
import { Button } from '@/components/ui/button';
import { ExternalLink, Github } from 'lucide-react';

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-braille-light">
      <header className="py-8 px-4 md:px-6 flex flex-col items-center justify-center">
        <h1 className="text-3xl md:text-4xl font-bold text-center text-gray-900 mb-2">
          BrailleCast
        </h1>
        <p className="text-lg text-center text-gray-600 max-w-2xl mb-8">
          Convert spoken or written text into Braille, making content more accessible.
        </p>
      </header>
      
      <main className="container px-4 md:px-6 pb-16">
        <BrailleConverter />
        
        <section className="mt-16 max-w-3xl mx-auto p-6 bg-white rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">About BrailleCast</h2>
          <p className="mb-4">
            BrailleCast helps bridge the gap between audio-visual content and Braille for visually impaired individuals. 
            Simply type text or record audio to generate Braille characters that can be copied, downloaded or shared.
          </p>
          <p className="mb-4">
            This is the first version of BrailleCast with basic functionality. Future versions will include:
          </p>
          <ul className="list-disc pl-6 mb-4 space-y-1">
            <li>Actual speech-to-text transcription</li>
            <li>Support for Grade 2 Braille (contractions)</li>
            <li>Embosser-ready output formats</li>
            <li>Multiple language support</li>
          </ul>
          
          <div className="flex justify-center gap-4 mt-8">
            <Button variant="outline" className="flex items-center">
              <Github className="mr-2 h-4 w-4" />
              View on GitHub
            </Button>
            <Button variant="outline" className="flex items-center">
              <ExternalLink className="mr-2 h-4 w-4" />
              Learn About Braille
            </Button>
          </div>
        </section>
      </main>
      
      <footer className="py-6 px-4 bg-gray-100 border-t">
        <div className="container mx-auto text-center text-gray-500 text-sm">
          BrailleCast - Making content accessible, one character at a time.
        </div>
      </footer>
    </div>
  );
};

export default Index;
