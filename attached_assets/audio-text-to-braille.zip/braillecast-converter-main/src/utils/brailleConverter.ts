
// Braille mapping for characters
const brailleMap: Record<string, string> = {
  'a': '⠁', 'b': '⠃', 'c': '⠉', 'd': '⠙', 'e': '⠑',
  'f': '⠋', 'g': '⠛', 'h': '⠓', 'i': '⠊', 'j': '⠚',
  'k': '⠅', 'l': '⠇', 'm': '⠍', 'n': '⠝', 'o': '⠕',
  'p': '⠏', 'q': '⠟', 'r': '⠗', 's': '⠎', 't': '⠞',
  'u': '⠥', 'v': '⠧', 'w': '⠺', 'x': '⠭', 'y': '⠽',
  'z': '⠵', ' ': '⠀', '0': '⠚', '1': '⠁', '2': '⠃',
  '3': '⠉', '4': '⠙', '5': '⠑', '6': '⠋', '7': '⠛',
  '8': '⠓', '9': '⠊', '.': '⠲', ',': '⠂', '?': '⠦',
  '!': '⠖', "'": '⠄', '"': '⠐⠂', '-': '⠤', ':': '⠒',
  ';': '⠆', '(': '⠐⠣', ')': '⠐⠜', '/': '⠸⠌'
};

/**
 * Convert text to Braille characters
 * @param text The text to convert
 * @returns The text converted to Braille
 */
export const textToBraille = (text: string): string => {
  if (!text) return '';
  
  return text
    .toLowerCase()
    .split('')
    .map(char => brailleMap[char] || char)
    .join('');
};

/**
 * Convert text to Braille cells for visual display
 * @param text The text to convert
 * @returns An array of characters with their braille representation
 */
export const textToBrailleCells = (text: string): Array<{original: string, braille: string}> => {
  if (!text) return [];
  
  return text
    .toLowerCase()
    .split('')
    .map(char => ({
      original: char,
      braille: brailleMap[char] || char
    }));
};
