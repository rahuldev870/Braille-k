
import React from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, ClipboardCopy, Eye } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { textToBrailleCells } from '@/utils/brailleConverter';

interface BrailleDisplayProps {
  text: string;
}

const BrailleDisplay: React.FC<BrailleDisplayProps> = ({ text }) => {
  const { toast } = useToast();
  const brailleText = textToBrailleCells(text);

  const copyToClipboard = () => {
    // Join just the braille characters
    const brailleString = brailleText.map(char => char.braille).join('');
    
    navigator.clipboard.writeText(brailleString).then(() => {
      toast({
        title: "Copied!",
        description: "Braille text copied to clipboard",
      });
    }).catch(err => {
      console.error("Failed to copy text: ", err);
      toast({
        title: "Copy failed",
        description: "Could not copy braille to clipboard",
        variant: "destructive",
      });
    });
  };

  const downloadBrailleText = () => {
    // Join just the braille characters
    const brailleString = brailleText.map(char => char.braille).join('');
    
    const element = document.createElement('a');
    const file = new Blob([brailleString], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = 'braille-text.txt';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    
    toast({
      title: "Downloaded!",
      description: "Braille text downloaded as a file",
    });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Eye className="mr-2 h-5 w-5" />
          <span>Braille Output</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="min-h-[120px] p-4 border rounded-md bg-braille-light flex flex-wrap gap-2">
          {brailleText.length === 0 ? (
            <p className="text-gray-500 w-full text-center">Converted Braille will appear here...</p>
          ) : (
            brailleText.map((char, index) => (
              <div 
                key={index} 
                className="flex flex-col items-center justify-center p-2 rounded-md bg-white shadow-sm hover:bg-braille-primary hover:text-white transition-colors"
                title={char.original !== ' ' ? `Original: ${char.original}` : 'Space'}
              >
                <span className="text-2xl">{char.braille}</span>
                <span className="text-xs mt-1 opacity-70">{char.original === ' ' ? 'space' : char.original}</span>
              </div>
            ))
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-end gap-2">
        {brailleText.length > 0 && (
          <>
            <Button 
              variant="outline" 
              onClick={copyToClipboard}
              className="flex items-center"
            >
              <ClipboardCopy className="mr-2 h-4 w-4" />
              Copy
            </Button>
            <Button 
              variant="default" 
              onClick={downloadBrailleText}
              className="flex items-center bg-braille-primary hover:bg-braille-dark"
            >
              <Download className="mr-2 h-4 w-4" />
              Download
            </Button>
          </>
        )}
      </CardFooter>
    </Card>
  );
};

export default BrailleDisplay;
