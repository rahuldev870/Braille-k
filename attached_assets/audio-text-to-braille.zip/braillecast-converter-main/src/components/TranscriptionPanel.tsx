
import React, { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Mic, StopCircle, FileText, ClipboardCopy } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

interface TranscriptionPanelProps {
  onTranscriptionChange: (text: string) => void;
}

const TranscriptionPanel: React.FC<TranscriptionPanelProps> = ({ 
  onTranscriptionChange 
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [text, setText] = useState("");
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const finalTranscriptRef = useRef<string>("");
  const { toast } = useToast();

  useEffect(() => {
    // Check browser support for speech recognition
    if (!('webkitSpeechRecognition' in window)) {
      toast({
        title: "Speech Recognition Unsupported",
        description: "Your browser does not support speech recognition.",
        variant: "destructive"
      });
      return;
    }

    // Initialize speech recognition
    recognitionRef.current = new (window as any).webkitSpeechRecognition();
    const recognition = recognitionRef.current;

    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let interimTranscript = '';
      let finalTranscript = finalTranscriptRef.current;
      
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript + ' ';
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }
      
      finalTranscriptRef.current = finalTranscript;
      
      // Set the full text (both final and interim)
      const fullText = finalTranscript + interimTranscript;
      setText(fullText);
      onTranscriptionChange(fullText);
    };

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      console.error('Speech recognition error:', event.error);
      toast({
        title: "Speech Recognition Error",
        description: event.error === 'no-speech' 
          ? "No speech was detected. Please try again." 
          : "An error occurred during speech recognition.",
        variant: "destructive"
      });
      setIsRecording(false);
    };

    recognition.onend = () => {
      // Only set isRecording to false if we're not purposefully restarting
      if (isRecording && recognitionRef.current) {
        // Auto restart if recording was not manually stopped
        recognitionRef.current.start();
      }
    };

    return () => {
      if (recognition) {
        recognition.stop();
      }
    };
  }, [onTranscriptionChange, toast, isRecording]);

  const startRecording = () => {
    if (recognitionRef.current) {
      // Clear previous text if starting a new recording session
      finalTranscriptRef.current = "";
      setText("");
      onTranscriptionChange("");
      
      recognitionRef.current.start();
      setIsRecording(true);
      toast({
        title: "Recording Started",
        description: "Speak clearly into your microphone",
      });
    }
  };

  const stopRecording = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsRecording(false);
      toast({
        title: "Recording Stopped",
        description: "Your speech has been transcribed",
      });
    }
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newText = e.target.value;
    setText(newText);
    onTranscriptionChange(newText);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Copied!",
        description: "Text copied to clipboard",
      });
    }).catch(err => {
      console.error("Failed to copy text: ", err);
      toast({
        title: "Copy failed",
        description: "Could not copy text to clipboard",
        variant: "destructive",
      });
    });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <FileText className="mr-2 h-5 w-5" />
          <span>Text Input</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Textarea
          placeholder="Type or record text to convert to Braille..."
          className="min-h-[120px] resize-y"
          value={text}
          onChange={handleTextChange}
        />
      </CardContent>
      <CardFooter className="flex justify-between">
        <div>
          {!isRecording ? (
            <Button 
              variant="outline" 
              onClick={startRecording}
              className="flex items-center"
            >
              <Mic className="mr-2 h-4 w-4" />
              Record Audio
            </Button>
          ) : (
            <Button 
              variant="destructive" 
              onClick={stopRecording}
              className="flex items-center animate-pulse-recording"
            >
              <StopCircle className="mr-2 h-4 w-4" />
              Stop Recording
            </Button>
          )}
        </div>
        {text && (
          <Button 
            variant="outline" 
            onClick={copyToClipboard}
            size="icon"
            title="Copy to clipboard"
          >
            <ClipboardCopy className="h-4 w-4" />
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default TranscriptionPanel;
