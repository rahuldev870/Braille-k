
import React, { useState } from 'react';
import TranscriptionPanel from './TranscriptionPanel';
import BrailleDisplay from './BrailleDisplay';

const BrailleConverter: React.FC = () => {
  const [inputText, setInputText] = useState('');

  const handleTranscriptionChange = (text: string) => {
    setInputText(text);
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      <TranscriptionPanel onTranscriptionChange={handleTranscriptionChange} />
      <BrailleDisplay text={inputText} />
    </div>
  );
};

export default BrailleConverter;
